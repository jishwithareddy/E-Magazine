
package com.mycompany.e.magazine;

public class Start {
    
    public static void main(String []args){
        
        onboarding st = new onboarding();
        st.setVisible(true);
        
    }
    
}
